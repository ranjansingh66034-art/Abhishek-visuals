ABHISHEK VISUALS — ANIME CINEMATIC PORTFOLIO
=============================================

FILES
- index.html: responsive portfolio website.
- assets/anime-hero.jpg: anime artwork for the homepage background.
- assets/anime-intro.jpg: anime artwork for the introduction/about section.

PREVIEW
Keep index.html and the assets folder together. Open index.html in a modern browser.
Internet is needed for Google Fonts and Google Drive embedded videos.

PUBLISH FREE WITH GITHUB PAGES
1. Create a public repository on GitHub.
2. Upload index.html AND the complete assets folder.
3. Open Settings → Pages.
4. Choose Deploy from a branch, select main and /(root), then Save.
5. Wait for GitHub Pages to provide your public website URL.

IMPORTANT
- Set each Google Drive video to General access: Anyone with the link — Viewer.
- Contact links are configured for the details supplied.
- The email button opens the visitor's email app; no backend form/database is included.
